﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TRAVEL_AGENCY
{
    class Tototo
    {
         public String  Ho, Tal;
        double Per, Days,Price, Tot;
        private string p;
        private string ho;
        private string tal;
        private double per;
        private double days;
        private double price;
        private double tot;

        public Tototo(String ho,String tal,int per,int days,int price,int tot)
        {
            this.Ho=ho;
            this.Days = days;
            this.Tal = tal;
            this.Per = per;
            this.Price = price;
            this.Tot = tot;
        }
        public String toString()
        {
            return
                  
                   "\n\tHotel               =\t'" + Ho  +'\'' +
                   "\n\tSpot                =\t'" + Tal   +'\'' +
                   "\n\tHotel Price      =\t'" + Price +'\'' +
                   "\n\tNo. of Persons      =\t'" + Per +'\'' +
                   "\n\tNo.of Days          =\t'" + Days   +'\'' +
                   "\n\tSummarize Expense   =\t'" + Tot  +'\'' +
                   ' ';
        }
        public Tototo(String ho, String tal)
        {
            Ho = ho;
            Tal = tal;
        }

        public Tototo(string p, string ho, string tal, double per, double days, double price, double tot)
        {
            // TODO: Complete member initialization
            this.p = p;
            this.ho = ho;
            this.tal = tal;
            this.per = per;
            this.days = days;
            this.price = price;
            this.tot = tot;
        }

    }
}
