﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TRAVEL_AGENCY
{
    class DataSet
    {
       
        public static List<TouristSpot> TouristSpotList = new List<TouristSpot>();
        public static List<User> UserList = new List<User>();
       
    }
}