﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TRAVEL_AGENCY
{
    class Edit
    {

        #region Removing Data

        public void Removed()
        {
            Console.ForegroundColor = ConsoleColor.Blue;
            Program p = new Program();
            Edit d = new Edit();

           



        login:
            String username, password;

            Console.WriteLine("\n\n\t\t\t\t\tREMOVED USER'S DATA\n");
            Console.Write("\n\n\t\t\t\t\tPlease Input  your Username:");
            username = Console.ReadLine();
            Console.Write("\n\t\t\t\t\tPlease Input your Password:");
            password = Console.ReadLine();

            try
            {
                User respond = DataSet.UserList.Find(r => (r.Username == username) && (r.Password == password));


                Console.WriteLine("\n\n\t\t\t\t\tPress D(delete)");
                Console.WriteLine("\n\n\t\t\t\t\tPress C(cancel)");
                Console.Write("\n\t\t\t\t\tCHOOSE OPTION:");
                string c = Console.ReadLine().ToString();


                switch (c)
                {
                    case "D":
                    case "d":
                        d.CLEAN(respond);

                        Console.WriteLine("\n\n\t\t\t\t\tYouved Successfully Deleted the following data!!!");

                        Console.Write("\n\n\t\t\t\t\tPress any key to Continue......");

                        Console.ReadLine();
                        Console.Clear();
                        p.ProgramStart();
                        Console.Clear();
                        Console.ReadLine();

                        break;
                    case "C":
                    case "c":
                        Console.WriteLine("\t\t\t\t\tcancelled");
                        Console.Read();
                        break;

                    default:

                        Console.Write("invalid input");
                        break;
                };

                Console.Read();
            }
            catch
            {
                Console.Clear();
                Console.WriteLine("Invalid Credentials !!!");
                goto login;
            }

        }




        #endregion

        #region Clean User

        public void CLEAN(User respond)
        {
            respond.FirstName = null;
            respond.Username= null;
            respond.LastName= null;
            respond.MiddleName = null;
            respond.Password = null;
            respond.Id = null;
            
         

        }


        #endregion



        public void ChangeTravelList()
        {
            TouristSpot ts = new TouristSpot();
            Console.ForegroundColor = ConsoleColor.Red;
            Program p = new Program();


                Console.WriteLine("\n\n\n\n\t\t\t\t\t\t\t\n\n");


            login:
                String username, password;
                ts.Art(1);
                Console.Write("\t\t        |                             LOGIN                             |");
                ts.Art(1);
                Console.Write("\n\t\t\t\t\tPlease Input your Username:");
                username = Console.ReadLine();
                Console.Write("\t\t\t\t\tPlease Input your Password:");
                password = Console.ReadLine();

                try
                {
                User respond = DataSet.UserList.Find(r => (r.Username == username) && (r.Password == password));
                Console.Clear();
                Console.WriteLine("\t\t\t\t\tWHAT DO YOU WANT TO CHANGE?");

               
                Console.WriteLine("A.FirstName");
                Console.WriteLine("B.Lastname");
                Console.WriteLine("C.MiddleName");
                Console.WriteLine("D.Username");
                Console.WriteLine("E.Password");
                Console.Write("\n\t\t\t\t\tWhat Is Your Choice?:");
                string Change = Console.ReadLine().ToString();

                if (Change == "A" || Change == "a")
                {
                    Console.Write("\n\t\t\t\t\tInput new Firstname:");
                    respond.FirstName = Console.ReadLine().ToString();
                }
                else if (Change == "B" || Change == "b")
                {
                    Console.Write("\n\t\t\t\t\tInput new Lastname:");
                    respond.LastName= Console.ReadLine().ToString();
                }
                else if (Change == "C" || Change == "c")
                {
                    Console.Write("\n\t\t\t\t\tInput new Middlename");
                    respond.MiddleName = Console.ReadLine().ToString();
                }
                else if (Change == "D" || Change == "d")
                {
                    Console.Write("\n\t\t\t\t\tInput new Username:");
                    respond.Username = Console.ReadLine().ToString();
                }
                else if (Change == "E" || Change == "e")
                {
                    Console.Write("\n\t\t\t\t\tInput new Password:");
                    respond.Password = Console.ReadLine().ToString();
                }
                
                {
                    Console.Read();

                }

            }

            catch
            {
                Console.Clear();
                Console.WriteLine("Invalid Credentials !!!");
                goto login;
            }


            Console.Write("\n\t\t\t\t\t\t\tPress any key to Continue......");

            Console.ReadLine();
            Console.Clear();
            p.ProgramStart();
            Console.Clear();
            Console.ReadLine();


        }

    }
}
