﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TRAVEL_AGENCY
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Program p = new Program();
            p.InitData();
            p.ProgramStart();
            Console.Read();
        }
        
        public void ProgramStart()
        {
            var guid = Guid.NewGuid().ToString();
            //Console.Write(guid);
            Program p = new Program();

        home:

            switch (p.Home())
            {
                case "a":
                case "A":
                    p.Login();
                    break;
                case "b":
                case "B":
                    p.Register();
                    break;
                default:
                    Console.Clear();
                    Console.WriteLine("\t\t\t\tInvalid Choice");
                    goto home;

            };
           
        }
        public void Logout()
        {
            Program p = new Program();
            p.ProgramStart();
            
        }
        public String Home()
        {
            
            string option;
            Console.WriteLine("\nxoxoxoxoxoxoxoxoxoxox xoxoxoxoxoxoxoxoxoxox xoxoxoxoxoxoxoxoxoxox xoxoxoxoxoxoxoxoxoxox");
            Console.Write("                      W E L C O M E TO NICKNAME TRAVEL AGENCY                        ");
            Console.WriteLine("\nxoxoxoxoxoxoxoxoxoxox xoxoxoxoxoxoxoxoxoxox xoxoxoxoxoxoxoxoxoxox xoxoxoxoxoxoxoxoxoxox");
            Console.WriteLine("|                                 OPTION                                              |");
            Console.WriteLine("|                                 A. Login                                            |");
            Console.WriteLine("|                                 B. Create an Account                                |");
            Console.Write("|_____________________________________________________________________________________|");
            Console.Write("\n\t\t\t\t  Select Option:\t");
            option = Console.ReadLine();
            Console.Clear();

            return option;
        }
        public void Login()
        {
            Program p = new Program();
            TouristSpot ts = new TouristSpot();
        login:
            string username, password;
            p.Art(1);
        Console.WriteLine("|                             LOGIN                             |");
            p.Art(1);
            Console.Write("Username: ");
            username = Console.ReadLine();
            System.Console.Write("\nPassword: ");
            password = null;

            while (true)
            {
                var key = System.Console.ReadKey(true);
                if (key.Key == ConsoleKey.Enter)
                    break;
                password += key.KeyChar;
                System.Console.Write("*");

            }
            Console.Clear();

            try
            {
                User respond = DataSet.UserList.Find(r => (r.Username == username) && (r.Password == password));

                switch (p.LoginHome(respond.Id))
                {
                    case "a":
                    case "A":
                        break;
                };
            }
            catch
            {

                Console.Clear();

                Console.WriteLine("\t\t\t\tInvalid Input");
                goto login;
            }

        }
        public void Cancel()
        {
            Program p = new Program();
        }
     
        public void Register()
        {
            Program p = new Program();
            String firstname, lastname, middlename, username, password;
            Console.WriteLine("\nxoxoxoxoxoxoxoxoxoxox xoxoxoxoxoxoxoxoxoxox xoxoxoxoxoxoxoxoxoxox");
            Console.Write("|                           Registration Form                   |");
            Console.WriteLine("\nxoxoxoxoxoxoxoxoxoxox xoxoxoxoxoxoxoxoxoxox xoxoxoxoxoxoxoxoxoxox");
            Console.Write("\tFirst Name:  ");
            firstname = Console.ReadLine();
            Console.Write("\tLast Name:   ");
            lastname = Console.ReadLine();
            Console.Write("\tMiddle Name: ");
            middlename = Console.ReadLine();
            Console.Write("\tUsername:    ");
            username = Console.ReadLine();
            Console.Write("\tPassword:    ");
            password = Console.ReadLine();
            Console.Clear();
                Console.WriteLine("\n\t\t\tYouved successfully register\n\t\t\t" + username + "\n\t\t\tkindly login");
                User u = new User(Guid.NewGuid().ToString(), firstname, lastname, middlename, username, password);
                DataSet.UserList.Add(u);
                ProgramStart();
        }
        public void Browse()
        {
        press:
            Program p = new Program();
            TouristSpot ts = new TouristSpot();
            string press;
            Console.WriteLine("|*************************************************************************************|");
            Console.WriteLine("|________________________________________BROWSE_______________________________________|");
            Console.WriteLine("| A.LUZON                                                                             |");
            Console.WriteLine("| B.VISAYAS                                                                           |");
            Console.WriteLine("| C.MINDANAO                                                                          |");
            Console.WriteLine("|_____________________________________________________________________________________|");
            Console.Write("Select from the following choices:");
            press = Console.ReadLine();
            switch (press)
            {
                case "A":
                case "a":
                    Console.Clear();
                    ts.Luzon();
                    break;
                case "B":
                case "b":
                    Console.Clear();
                    ts.Visayas();
                    break;
                case "C":
                case "c":
                    Console.Clear();
                    ts.Mindanao();
                    break;
               
                default:
                    Console.Clear();
                    Console.WriteLine("invalid input try again");
                    goto press;
            }
        }
       
        public String LoginHome(String id)
        {
            home:
            Program p=new Program();
            TouristSpot ts = new TouristSpot();
            User respond;
            String browse="";
            try
            {
                respond = DataSet.UserList.Find(r => (r.Id == id));
               
                
            Console.WriteLine("|*************************************************************************************|");
            Console.WriteLine("|__________________________________________MENU_______________________________________|");
            Console.WriteLine("| A.BROWSE                                                                            |");
            Console.WriteLine("| B.LOGOUT                                                                            |");
            Console.WriteLine("|_____________________________________________________________________________________|");
            Console.Write("Select from the following choices:");
            browse = Console.ReadLine();
            switch (browse)
            {
                case "A":
                case "a":
                    Console.Clear();
                    Browse();
                    break;
                case "B":
                case "b":
                    Console.Clear();
                    Logout();
                    break;
                default:
                    Console.Clear();
                    Console.WriteLine("invalid input try again");
                    goto home;
            }
        
               

            }
            catch
            {
             
            }

            return browse;
        }
       /*public void AccountSetting()
        {
            Program p=new Program();
            Edit d = new Edit();
            AccountSetting:
            string select;
            Console.WriteLine("|*************************************************************************************|");
            Console.WriteLine("|___________________________________ Account Setting__________________________________|");
            Console.WriteLine("| A.My Travel List                                                                    |");
            Console.WriteLine("| B.Back                                                                              |");
            Console.WriteLine("|_____________________________________________________________________________________|");
            Console.Write("\t\t\t\t\tSelect:\t\t");
            select = Console.ReadLine();
            switch (select)
            {
                case "a":
                case "A":
                    Console.Clear();
                    //DisplayTravelList();
                    break;
                case "b":
                case "B":
                    Console.Clear();
                    p.Back();
                    break;
                default:
                    Console.Clear();
                    Console.WriteLine("invalid input please try again");
                    goto AccountSetting;
            }
            
        }*/
        public void DisplayUserList()
        {
            Program p = new Program();
            String choice;
            do
            {
                Console.WriteLine("\nxoxoxoxoxoxoxoxoxoxox xoxoxoxoxoxoxoxoxoxox xoxoxoxoxoxoxoxoxoxox");
                Console.Write("|                           Users List                          |");
                Console.WriteLine("\nxoxoxoxoxoxoxoxoxoxox xoxoxoxoxoxoxoxoxoxox xoxoxoxoxoxoxoxoxoxox");
                int count = 1;
                foreach (User s in DataSet.UserList)
                {
                    try
                    {

                        Console.WriteLine(count++ + " " + s.toString());
                    }
                    catch
                    {

                    }

                }
                Console.Write("Do you want another transaction?\tPress Enter key");
                choice = Console.ReadLine();
            } while (choice == "y" || choice == "Y");
           //p.AccountSetting();


        }
         /*public void DisplayTravelList()
             {
                 Program p = new Program();
               
                 String choice;
                 do
                 {
                     Console.WriteLine("\nxoxoxoxoxoxoxoxoxoxox xoxoxoxoxoxoxoxoxoxox xoxoxoxoxoxoxoxoxoxox");
                     Console.Write("|                         My Travel List                        |");
                     Console.WriteLine("\nxoxoxoxoxoxoxoxoxoxox xoxoxoxoxoxoxoxoxoxox xoxoxoxoxoxoxoxoxoxox");
                     int blink = 1;
                     foreach (TouristSpot ts in DataSet.TouristSpotList)
                         
                     {
                         try
                         {

                             Console.WriteLine(blink ++ + " " + ts.toString());
                             
                         }
                         catch
                         {

                         }

                     }
                     Console.Write("Do you want another transaction?\tPress Enter key");
                     choice = Console.ReadLine();
                 } while (choice == "y" || choice == "Y");
                 p.Browse();

             }*/

         public void InitData()
         {
             string id1 = Guid.NewGuid().ToString();
             DataSet.UserList.Add(new User(Guid.NewGuid().ToString(), "nick", "name", "m", "nick", "name"));

         }
        public void Art(byte d)
        {
            for (int c = 1; c <= d; c++)
            {
                Console.WriteLine("xoxoxoxoxoxoxoxoxoxox xoxoxoxoxoxoxoxoxoxox xoxoxoxoxoxoxoxoxoxox");
            }
        }

        internal void home()
        {
            throw new NotImplementedException();
        }
    }
}