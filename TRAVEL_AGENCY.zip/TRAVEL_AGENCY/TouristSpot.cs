﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TRAVEL_AGENCY
{
    class TouristSpot
    {
        public void TAALLAKE()
        {
            Program p = new Program();
            TouristSpot ts = new TouristSpot();
            string z,b;
            int person, total, days,d,m,yy;
            int hotelprice;
            Console.WriteLine("\nWELCOME TO TAAL LAKE TAGAYTAY PHILIPPINES\nHotel:View Park Hotel\nHotel Price:P2000\nPress[Y] to continue and Press[N] to Browse again");
            z = Console.ReadLine();
            if (z == "y" || z == "Y")
            {
            d:
                Console.WriteLine("Enter Day (DD):");
                d = int.Parse(Console.ReadLine());
                if (d > 0 && d < 32)
                {
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto d;
                }
            m:
                   Console.WriteLine("Enter Month (MM):");
                    m = int.Parse(Console.ReadLine());
               if (m> 0 && m<= 12)
                {  
                }
               else
               {
                   Console.Clear();
                   Console.WriteLine("invalid input");
                   goto m;
               }
            yy:
                    Console.WriteLine("Enter year(YYYY):");
                    yy = int.Parse(Console.ReadLine());
               if (yy == 2018){
                
                }
               else if (yy != 2018)
               {
                   Console.Clear();
                   Console.WriteLine("invalid input");
                   goto yy;
               }
               
               
               hotelprice = 2000;
                Console.Write("\nHow many Person:");
                person = int.Parse(Console.ReadLine());
                Console.Write("\nHow many days:");
                days = int.Parse(Console.ReadLine());
                total = ((hotelprice * person) * days);
                Console.Clear();
                Q(1);
                Console.WriteLine("|                         My Travel List                        |");
                Q(1);
                Console.WriteLine("TouristSpot        \tTaal Lake");
                Console.WriteLine("Location           \tTagaytay Philippines");
                Console.WriteLine("Hotel              \tView Park Hotel");
                Console.WriteLine("Total person       \t" + person);
                Console.WriteLine("Total Days         \t" + days);
                Console.WriteLine("Hotel Price        \t" + hotelprice);
                Console.WriteLine("Summarize expense  \t" + total);
                Console.WriteLine("Date               \t" + d +"/"+ m +"/"+ yy);
                Q(1);
                Q(2);
                Console.WriteLine("What to do next? Press [Y] to goto Menu and [N] if you want to Logout");
                b=Console.ReadLine();
                if (b == "y" || b == "Y")
                {
                    Console.Clear();
                    p.Browse();
                }
                else if (b != "y" || b != "Y")
                {
                    Console.Clear();
                Luzon();
                }
                else if (b == "n" || b == "N")
                {
                    Console.Clear();
                    p.Logout();
                }

            }
            else
            {
                Console.Clear();
               Luzon();
            }
        }
        public void MAYONVOLCANO()
        {
            Program p = new Program();
            TouristSpot ts = new TouristSpot();
            string z,b;
            int person, total, days,d,m,yy;
            int hotelprice;
            Console.WriteLine("\nWELCOME TO MT.MAYON LEGAZPI ALBAY PHILIPPINES\nHOTEL:ST.ELLIS\nHotel Price:P3000/day\nDo you like this place?[Y]to continue Press[N]  browse again");
            z = Console.ReadLine();
            if (z == "y" || z == "Y")
            {
            d:
                Console.WriteLine("Enter Day (DD):");
                d = int.Parse(Console.ReadLine());
                if (d > 0 && d < 32)
                {
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto d;
                }
            m:
                Console.WriteLine("Enter Month (MM):");
                m = int.Parse(Console.ReadLine());
                if (m > 0 && m <= 12)
                {
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto m;
                }
            yy:
                Console.WriteLine("Enter year(YYYY):");
                yy = int.Parse(Console.ReadLine());
                if (yy == 2018)
                {

                }
                else if (yy != 2018)
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto yy;
                }
               
                hotelprice = 3000;
                Console.Write("\nHow many Person:");
                person = int.Parse(Console.ReadLine());
                Console.Write("\nHow many days:");
                days = int.Parse(Console.ReadLine());
                total = ((hotelprice * person) * days);
                Console.Clear();
                Q(1);
                Console.WriteLine("|                         My Travel List                        |");
                Q(1);
                Console.WriteLine("TouristSpot        \tMt.Mayon Volcano");
                Console.WriteLine("Location           \tLegazpi Albay Philippines");
                Console.WriteLine("Hotel              \tSt.Ellis");
                Console.WriteLine("Total person       \t" + person);
                Console.WriteLine("Total Days         \t" + days);
                Console.WriteLine("\nHotel Price      \t" + hotelprice);
                Console.WriteLine("\nSummarize expense\t" + total);
                Console.WriteLine("Date               \t" + d + "/" + m + "/" + yy);
                Q(1);
                Q(2);
                Console.WriteLine("What to do next? Press [Y] to goto Menu and [N] if you want to Logout");
                b = Console.ReadLine();
                if (b == "y" || b == "Y")
                {
                    Console.Clear();
                    p.Browse();
                }
                else if (b != "y" || b != "Y")
                {
                    Console.Clear();
                    Luzon();
                }
                else if (b == "n" || b == "N")
                {
                    Console.Clear();
                    p.Logout();
                }

            }
            else
            {
                Console.Clear();
                Luzon();
            }
        }
        public void MANILAOCEANPARK()
        {

            Program p = new Program();
            TouristSpot ts = new TouristSpot();
            string z,b;
            int person, total, days,d,m,yy;
            int hotelprice;
            Console.WriteLine("\nWELCOME MANILA OCEAN PARK\nHOTEL:MANILA HOTEL\nHotel Price:P7000/day\nDo you like this place?[Y]to continue Press[N]  browse again");
            z = Console.ReadLine();
            if (z == "y" || z == "Y")
            {
            d:
                Console.WriteLine("Enter Day (DD):");
                d = int.Parse(Console.ReadLine());
                if (d > 0 && d < 32)
                {
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto d;
                }
            m:
                Console.WriteLine("Enter Month (MM):");
                m = int.Parse(Console.ReadLine());
                if (m > 0 && m <= 12)
                {
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto m;
                }
            yy:
                Console.WriteLine("Enter year(YYYY):");
                yy = int.Parse(Console.ReadLine());
                if (yy == 2018)
                {

                }
                else if (yy != 2018)
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto yy;
                }
               
                hotelprice = 7000;
                Console.Write("\nHow many Person:");
                person = int.Parse(Console.ReadLine());
                Console.Write("\nHow many days:");
                days = int.Parse(Console.ReadLine());
                total = ((hotelprice * person) * days);
                Console.Clear();
                Q(1);
                Console.WriteLine("|                         My Travel List                        |");
                Q(1);
                Console.WriteLine("TouristSpot        \tManila Ocean Park");
                Console.WriteLine("Location           \tManila Philippines");
                Console.WriteLine("Hotel              \tManila Hotel");
                Console.WriteLine("Total person       \t" + person);
                Console.WriteLine("Total Days         \t" + days);
                Console.WriteLine("\nHotel Price      \t" + hotelprice);
                Console.WriteLine("\nSummarize expense\t" + total);
                Console.WriteLine("Date               \t" + d + "/" + m + "/" + yy);
                Q(1);
                Q(2);
                Console.WriteLine("What to do next? Press [Y] to goto Menu and [N] if you want to Logout");
                b = Console.ReadLine();
                if (b == "y" || b == "Y")
                {
                    Console.Clear();
                    p.Browse();
                }
                else if (b != "y" || b != "Y")
                {
                    Console.Clear();
                    Luzon();
                }
                else if (b == "n" || b == "N")
                {
                    Console.Clear();
                    p.Logout();
                }

            }
            else
            {
                Console.Clear();
                Luzon();
            }
        }
        public void UNDERGROUNDRIVER()
        {

            Program p = new Program();
            TouristSpot ts = new TouristSpot();
            string z,b;
            int person, total, days,d,m,yy;
            int hotelprice;
            Console.WriteLine("\nUNDERGROUND RIVER EL NIDO PALAWAN\nHOTEL:CHANTAL\nHotel Price:P4000/day\nDo you like this place?[Y]to continue Press[N]  browse again");
            z = Console.ReadLine();
            if (z == "y" || z == "Y")
            {
            d:
                Console.WriteLine("Enter Day (DD):");
                d = int.Parse(Console.ReadLine());
                if (d > 0 && d < 32)
                {
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto d;
                }
            m:
                Console.WriteLine("Enter Month (MM):");
                m = int.Parse(Console.ReadLine());
                if (m > 0 && m <= 12)
                {
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto m;
                }
            yy:
                Console.WriteLine("Enter year(YYYY):");
                yy = int.Parse(Console.ReadLine());
                if (yy == 2018)
                {

                }
                else if (yy != 2018)
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto yy;
                }
               
                hotelprice = 4000;
                Console.Write("\nHow many Person:");
                person = int.Parse(Console.ReadLine());
                Console.Write("\nHow many days:");
                days = int.Parse(Console.ReadLine());
                total = ((hotelprice * person) * days);
                  Console.Clear();
                Q(1);
                Console.WriteLine("|                         My Travel List                        |");
                Q(1);
                Console.WriteLine("TouristSpot        \tUnderGround River");
                Console.WriteLine("Location           \tEl Nido Palawan Philippines");
                Console.WriteLine("Hotel              \tChantal Hotel");
                Console.WriteLine("Total person       \t" + person);
                Console.WriteLine("Total Days         \t" + days);
                Console.WriteLine("\nHotel Price      \t" + hotelprice);
                Console.WriteLine("\nSummarize expense\t" + total);
                Console.WriteLine("Date               \t" + d + "/" + m + "/" + yy);
                Q(1);
                Q(2);
                Console.WriteLine("What to do next? Press [Y] to goto Menu and [N] if you want to Logout");
                b=Console.ReadLine();
                if (b == "y" || b == "Y")
                {
                    Console.Clear();
                    p.Browse();
                }
                else if (b != "y" || b != "Y")
                {
                    Console.Clear();
                    Luzon();
                }
                else if (b == "n" || b == "N")
                {
                    Console.Clear();
                    p.Logout();
                }

            }
            else
            {
                Console.Clear();
                Luzon();
            }
        }
        
        public void BANAUERICETERRACES()
        {

            Program p = new Program();
            TouristSpot ts = new TouristSpot();
            string z,b;
            int person, total, days,d,m,yy;
            int hotelprice;
            Console.WriteLine("\nWELCOME TO BANAUE RICE TERRACES BENGUET PHILIPPINES\nHOTEL:CHALET HOTEL\nHOTEL PRICE:P2500/day\nDo you like this place?[Y]to continue Press[N]  browse again");
            z = Console.ReadLine();
            if (z == "y" || z == "Y")
            {
            d:
                Console.WriteLine("Enter Day (DD):");
                d = int.Parse(Console.ReadLine());
                if (d > 0 && d < 32)
                {
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto d;
                }
            m:
                Console.WriteLine("Enter Month (MM):");
                m = int.Parse(Console.ReadLine());
                if (m > 0 && m <= 12)
                {
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto m;
                }
            yy:
                Console.WriteLine("Enter year(YYYY):");
                yy = int.Parse(Console.ReadLine());
                if (yy == 2018)
                {

                }
                else if (yy != 2018)
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto yy;
                }
               
                hotelprice = 2500;
                Console.Write("\nHow many Person:");
                person = int.Parse(Console.ReadLine());
                Console.Write("\nHow many days:");
                days = int.Parse(Console.ReadLine());
                total = ((hotelprice * person) * days);
                Console.Clear();
                Q(1);
                Console.WriteLine("|                         My Travel List                        |");
                Q(1);
                Console.WriteLine("TouristSpot        \tBanaue Rice Terraces");
                Console.WriteLine("Location           \tBenguet Philippines");
                Console.WriteLine("Hotel              \tChalet Hotel");
                Console.WriteLine("Total person       \t" + person);
                Console.WriteLine("Total Days         \t" + days);
                Console.WriteLine("\nHotel Price      \t" + hotelprice);
                Console.WriteLine("\nSummarize expense\t" + total);
                Console.WriteLine("Date               \t" + d + "/" + m + "/" + yy);
                Q(1);
                Q(2);
                Console.WriteLine("What to do next? Press [Y] to goto Menu and [N] if you want to Logout");
                b = Console.ReadLine();
                if (b == "y" || b == "Y")
                {
                    Console.Clear();
                    p.Browse();
                }
                else if (b != "y" || b != "Y")
                {
                    Console.Clear();
                    Luzon();
                }
                else if (b == "n" || b == "N")
                {
                    Console.Clear();
                    p.Logout();
                }

            }
            else
            {
                Console.Clear();
                Luzon();
            }
        }
        public void FORTSANTIAGO()
        {

            Program p = new Program();
            TouristSpot ts = new TouristSpot();
            string z,b;
            int person, total, days,d,m,yy;
            int hotelprice;
            Console.WriteLine("\nWELCOME TO FORT SANTIAGO INTRAMUROS MANILA\nHOTEL:MANILA HOTEL\nHOTEL PRICE:P7000/day\nDo you like this place?[Y]to continue Press[N]  browse again");
            z = Console.ReadLine();
            if (z == "y" || z == "Y")
            {
            d:
                Console.WriteLine("Enter Day (DD):");
                d = int.Parse(Console.ReadLine());
                if (d > 0 && d < 32)
                {
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto d;
                }
            m:
                Console.WriteLine("Enter Month (MM):");
                m = int.Parse(Console.ReadLine());
                if (m > 0 && m <= 12)
                {
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto m;
                }
            yy:
                Console.WriteLine("Enter year(YYYY):");
                yy = int.Parse(Console.ReadLine());
                if (yy == 2018)
                {

                }
                else if (yy != 2018)
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto yy;
                }
               
                hotelprice = 7000;
                Console.Write("\nHow many Person:");
                person = int.Parse(Console.ReadLine());
                Console.Write("\nHow many days:");
                days = int.Parse(Console.ReadLine());
                total = ((hotelprice * person) * days);
                Console.Clear();
                Q(1);
                Console.WriteLine("|                         My Travel List                        |");
                Q(1);
                Console.WriteLine("TouristSpot        \tFort Santiago");
                Console.WriteLine("Location           \tIntramuros Manila Philippines");
                Console.WriteLine("Hotel              \tManila Hotel");
                Console.WriteLine("Total person       \t" + person);
                Console.WriteLine("Total Days         \t" + days);
                Console.WriteLine("\nHotel Price      \t" + hotelprice);
                Console.WriteLine("\nSummarize expense\t" + total);
                Console.WriteLine("Date               \t" + d + "/" + m + "/" + yy);
                Q(1);
                Q(2);
                Console.WriteLine("What to do next? Press [Y] to goto Menu and [N] if you want to Logout");
                b = Console.ReadLine();
                if (b == "y" || b == "Y")
                {
                    Console.Clear();
                    p.Browse();
                }
                else if (b != "y" || b != "Y")
                {
                    Console.Clear();
                    Luzon();
                }
                else if (b == "n" || b == "N")
                {
                    Console.Clear();
                    p.Logout();
                }

            }
            else
            {
                Console.Clear();
                Luzon
                    ();
            }
        }
        public void Luzon()
        {
        Luzon:
            
            Program p = new Program();
            TouristSpot ts = new TouristSpot();
            string L;

            Art(1);
            Console.WriteLine("\nWelcome to Luzon's TOP 5 Tourist Spots\nHappy Browsing");
            Art(1);
            Console.WriteLine("\nA.Taal lake \nB.Mt.Mayon \nC.Manila Ocean Park \nD.UnderGround River \nE.Fort Santiago");
            Art(1);
            Console.Write("\nplease select:\t");
            L = Console.ReadLine();
            switch (L)
            {
                case "A":
                case "a":
                    Console.Clear();
                    ts.TAALLAKE();

                    break;
                case "b":
                case "B":

                    Console.Clear();
                    ts.MAYONVOLCANO();
                    break;
                case "c":
                case "C":
                    Console.Clear();
                    ts.BANAUERICETERRACES();
                    break;
                case "D":
                case "d":
                    Console.Clear();
                    ts.UNDERGROUNDRIVER();
                    break;
                case "e":
                case "E":
                    Console.Clear();
                    ts.FORTSANTIAGO();
                    break;
                default:
                    Console.Clear();
                    Console.WriteLine("Invalid input");
                    goto Luzon;
            }
        }

        public void DANAOLAKE()
        {

            Program p = new Program();
            TouristSpot ts = new TouristSpot();
            string z,b;
            int person, total, days,d,m,yy;
            int hotelprice;
            Console.WriteLine("\nDANAO LAKE SAN JUAN CABALIAN SOUTHERN LEYTE\nHOTEL:KISSBONE COVE HOTEL AND RESORT \nHOTEL PRICE:P2000/day\nDo you like this place?[Y]to continue Press[N]  browse again");
            z = Console.ReadLine();
            if (z == "y" || z == "Y")
            {
            d:
                Console.WriteLine("Enter Day (DD):");
                d = int.Parse(Console.ReadLine());
                if (d > 0 && d < 32)
                {
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto d;
                }
            m:
                Console.WriteLine("Enter Month (MM):");
                m = int.Parse(Console.ReadLine());
                if (m > 0 && m <= 12)
                {
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto m;
                }
            yy:
                Console.WriteLine("Enter year(YYYY):");
                yy = int.Parse(Console.ReadLine());
                if (yy == 2018)
                {

                }
                else if (yy != 2018)
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto yy;
                }
               
                hotelprice = 2000;
                Console.Write("\nHow many Person:");
                person = int.Parse(Console.ReadLine());
                Console.Write("\nHow many days:");
                days = int.Parse(Console.ReadLine());
                total = ((hotelprice * person) * days);
                Console.Clear();
                Q(1);
                Console.WriteLine("|                         My Travel List                        |");
                Q(1);
                Console.WriteLine("TouristSpot        \tDanao Lake");
                Console.WriteLine("Location           \tSan Juan Southern Leyte Philippines");
                Console.WriteLine("Hotel              \tKissbone Cove Hotel and Resort");
                Console.WriteLine("Total person       \t" + person);
                Console.WriteLine("Total Days         \t" + days);
                Console.WriteLine("\nHotel Price      \t" + hotelprice);
                Console.WriteLine("\nSummarize expense\t" + total);
                Console.WriteLine("Date               \t" + d + "/" + m + "/" + yy);
                Q(1);
                Q(2);
                Console.WriteLine("What to do next? Press [Y] to goto Menu and [N] if you want to Logout");
                b = Console.ReadLine();
                if (b == "y" || b == "Y")
                {
                    Console.Clear();
                    p.Browse();
                  
                }
                else if (b != "y" || b != "Y")
                {
                    Console.Clear();
                    Visayas();
                }
                   
                else if (b == "n" || b == "N")
                {
                    Console.Clear();
                    p.Logout();
                }

            }
            else
            {
                Console.Clear();
                Visayas();
            }
        }
        public void LAKEKABALINan()
        {

            Program p = new Program();
            TouristSpot ts = new TouristSpot();
            string z,b;
            int person, total, days,d,m,yy;
            int hotelprice;
            Console.WriteLine("\nLAKE KABALIN-AN NEGROS ORIENTAL\nHOTEL NAME:BRAVO HOTEL\nHOTEL PRICE:P3000/day\nPress[Y]to continue Press[N] to browse another spot");
            z = Console.ReadLine();
            if (z == "y" || z == "Y")
            {
            d:
                Console.WriteLine("Enter Day (DD):");
                d = int.Parse(Console.ReadLine());
               if (d > 0 && d < 32)
                {
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto d;
                }
            m:
                Console.WriteLine("Enter Month (MM):");
                m = int.Parse(Console.ReadLine());
                if (m > 0 && m <= 12)
                {
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto m;
                }
            yy:
                Console.WriteLine("Enter year(YYYY):");
                yy = int.Parse(Console.ReadLine());
                if (yy == 2018)
                {

                }
                else if (yy != 2018)
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto yy;
                }
               
                hotelprice = 3000;
                Console.Write("\nHow many Person:");
                person = int.Parse(Console.ReadLine());
                Console.Write("\nHow many days:");
                days = int.Parse(Console.ReadLine());
                total = ((hotelprice * person) * days);
                Console.Clear();
                Q(1);
                Console.WriteLine("|                         My Travel List                        |");
                Q(1);
                Console.WriteLine("TouristSpot        \tKabalin-an Lake");
                Console.WriteLine("Location           \tNegros Oriental Philippines");
                Console.WriteLine("Hotel              \tBravo Hotel");
                Console.WriteLine("Total person       \t" + person);
                Console.WriteLine("Total Days         \t" + days);
                Console.WriteLine("\nHotel Price      \t" + hotelprice);
                Console.WriteLine("\nSummarize expense\t" + total);
                Console.WriteLine("Date               \t" + d + "/" + m + "/" + yy);
                Q(1);
                Q(2);
                Console.WriteLine("What to do next? Press [Y] to goto Menu and [N] if you want to Logout");
                b = Console.ReadLine();
                if (b == "y" || b == "Y")
                {
                    Console.Clear();
                    p.Browse();
                }
                else if (b != "y" || b != "Y")
                {
                    Console.Clear();
                    Visayas();
                }
                else if (b == "n" || b == "N")
                {
                    Console.Clear();
                    p.Logout();
                }

            }
            else
            {
                Console.Clear();
                Visayas();
            }
        }
        public void CHOCOLATEHILLS()
        {

            Program p = new Program();
            TouristSpot ts = new TouristSpot();
            string z,b;
            int person, total, days,d,m,yy;
            int hotelprice;
            Console.WriteLine("\nWELCOME TO CHOCOLATE HILLS CARMEN BOHOL PHILIPPINES\nHOTEL NAME:ASTORIA BOHOL\nHOTEL PRICE:P2500/daynPress[Y]to continue Press[N] to browse another spot");
            z = Console.ReadLine();
            if (z == "y" || z == "Y")
            {
            d:
                Console.WriteLine("Enter Day (DD):");
                d = int.Parse(Console.ReadLine());
                if (d > 0 && d < 32)
                {
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto d;
                }
            m:
                Console.WriteLine("Enter Month (MM):");
                m = int.Parse(Console.ReadLine());
                if (m > 0 && m <= 12)
                {
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto m;
                }
            yy:
                Console.WriteLine("Enter year(YYYY):");
                yy = int.Parse(Console.ReadLine());
                if (yy == 2018)
                {

                }
                else if (yy != 2018)
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto yy;
                }
               
                hotelprice = 2500;
                Console.Write("\nHow many Person:");
                person = int.Parse(Console.ReadLine());
                Console.Write("\nHow many days:");
                days = int.Parse(Console.ReadLine());
                total = ((hotelprice * person) * days);
                Console.Clear();
                Q(1);
                Console.WriteLine("|                         My Travel List                        |");
                Q(1);
                Console.WriteLine("TouristSpot        \tChocolate Hills");
                Console.WriteLine("Location           \tCarmen Bohol Philippines");
                Console.WriteLine("Hotel              \tAstoria Bohol");
                Console.WriteLine("Total person       \t" + person);
                Console.WriteLine("Total Days         \t" + days);
                Console.WriteLine("\nHotel Price      \t" + hotelprice);
                Console.WriteLine("\nSummarize expense\t" + total);
                Console.WriteLine("Date               \t" + d + "/" + m + "/" + yy);
                Q(1);
                Q(2);
                Console.WriteLine("What to do next? Press [Y] to goto Menu and [N] if you want to Logout");
                b = Console.ReadLine();
                if (b == "y" || b == "Y")
                {
                    Console.Clear();
                    p.Browse();
                }
                else if (b != "y" || b != "Y")
                {
                    Console.Clear();
                    Visayas();
                }
                else if (b == "n" || b == "N")
                {
                    Console.Clear();
                    p.Logout();
                }

            }
            else
            {
                Console.Clear();
                Visayas();
            }
        }
        public void UNDERWATERCEMETERY()
        {

            Program p = new Program();
            TouristSpot ts = new TouristSpot();
            string z,b;
            int person, total, days,d,m,yy;
            int hotelprice;
            ts.Art(1);
            Console.WriteLine("\nUNDERWATER CEMETERY CAMIGUIN PHILIPPINES\nHOTEL NAME:THE LOFT INN AND RESORT\nHOTEL PRICE:P2000/days\nPress[Y]to continue Press[N] to browse another spot");
            ts.Art(1);
            z = Console.ReadLine();
            if (z == "y" || z == "Y")
            {
            d:
                Console.WriteLine("Enter Day (DD):");
                d = int.Parse(Console.ReadLine());
                if (d > 0 && d < 32)
                {
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto d;
                }
            m:
                Console.WriteLine("Enter Month (MM):");
                m = int.Parse(Console.ReadLine());
                if (m > 0 && m <= 12)
                {
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto m;
                }
            yy:
                Console.WriteLine("Enter year(YYYY):");
                yy = int.Parse(Console.ReadLine());
                if (yy == 2018)
                {

                }
                else if (yy != 2018)
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto yy;
                }
               
                hotelprice = 2000;
                Console.Write("\nHow many Person:");
                person = int.Parse(Console.ReadLine());
                Console.Write("\nHow many days:");
                days = int.Parse(Console.ReadLine());
                total = ((hotelprice * person) * days);
                Console.Clear();
                Q(1);
                Console.WriteLine("|                         My Travel List                        |");
                Q(1);
                Console.WriteLine("TouristSpot        \tUnderwater Cemetery");
                Console.WriteLine("Location           \tCamiguin Philippines");
                Console.WriteLine("Hotel              \tThe Loft Inn and Resort");
                Console.WriteLine("Total person       \t" + person);
                Console.WriteLine("Total Days         \t" + days);
                Console.WriteLine("\nHotel Price      \t" + hotelprice);
                Console.WriteLine("\nSummarize expense\t" + total);
                Console.WriteLine("Date               \t" + d + "/" + m + "/" + yy);
                Q(1);
                Q(2);
                Console.WriteLine("What to do next? Press [Y] to goto Menu and [N] if you want to Logout");
                b = Console.ReadLine();
                if (b == "y" || b == "Y")
                {
                    Console.Clear();
                    p.Browse();
                }
                else if (b != "y" || b != "Y")
                {
                    Console.Clear();
                    Visayas();
                }
                else if (b == "n" || b == "N")
                {
                    Console.Clear();
                    p.Logout();
                }

            }
            else
            {
                Console.Clear();
                Visayas();
            }
        }
        public void CANIGAOISLAND()
        {

            Program p = new Program();
            TouristSpot ts = new TouristSpot();
            string z, b;
            int person, total, days,d,m,yy;
            int hotelprice;
            Console.WriteLine("\nWELCOME TO CANIGAO ISLAND PARADISE\nHOTEL NAME:JAMES HOTEL AND RESORT HOTEL PRICE:P1500/day\nPress[Y]to continue Press[N] to browse another spot");
            z = Console.ReadLine();
            if (z == "y" || z == "Y")
            {
            d:
                Console.WriteLine("Enter Day (DD):");
                d = int.Parse(Console.ReadLine());
                if (d > 0 && d < 32)
                {
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto d;
                }
            m:
                Console.WriteLine("Enter Month (MM):");
                m = int.Parse(Console.ReadLine());
                if (m > 0 && m <= 12)
                {
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto m;
                }
            yy:
                Console.WriteLine("Enter year(YYYY):");
                yy = int.Parse(Console.ReadLine());
                if (yy == 2018)
                {

                }
                else if (yy != 2018)
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto yy;
                }
               
                hotelprice = 1500;
                Console.Write("\nHow many Person:");
                person = int.Parse(Console.ReadLine());
                Console.Write("\nHow many days:");
                days = int.Parse(Console.ReadLine());
                total = ((hotelprice * person) * days);
                Console.Clear();
                Q(1);
                Console.WriteLine("|                         My Travel List                        |");
                Q(1);
                Console.WriteLine("TouristSpot        \tCanigao Island Paradise");
                Console.WriteLine("Location           \tCaninao Leyte Philippines");
                Console.WriteLine("Hotel              \tJames Hotel");
                Console.WriteLine("Total person       \t" + person);
                Console.WriteLine("Total Days         \t" + days);
                Console.WriteLine("\nHotel Price      \t" + hotelprice);
                Console.WriteLine("\nSummarize expense\t" + total);
                Console.WriteLine("Date               \t" + d + "/" + m + "/" + yy);
                Q(1);
                Q(2);
                Console.WriteLine("What to do next? Press [Y] to goto Menu and [N] if you want to Logout");
                b = Console.ReadLine();
                if (b == "y" || b == "Y")
                {
                    Console.Clear();
                    p.Browse();
                }
                else if (b != "y" || b != "Y")
                {
                    Console.Clear();
                    Visayas();
                }
                else if (b == "n" || b == "N")
                {
                    Console.Clear();
                    p.Logout();
                }

            }
            else
            {
                Console.Clear();
                Visayas();
            }
        }
        public void Visayas()
        {
            TouristSpot ts = new TouristSpot();
            Program p = new Program();
        Visayas:
            String V;
            Art(1);
            Console.WriteLine("\nWelcome to Visayas's TOP 5 Tourist Spots\nHappy Browsing");
            Art(1);
            Console.WriteLine("\nA.Danao lake Cabalian Southern Leyte\nB.Lake Kabalin-an Negros Oriental\nC.Chocolate hills Bohol\nD.Underwater Cemetery Camiguin\nE.Canigao Island Paradise");
            Art(1);
            Console.Write("kindly choose:\t");
            V = Console.ReadLine();
            switch (V)
            {
                case "a":
                case "A":
                    Console.Clear();
                    ts.DANAOLAKE();
                    break;
                case "b":
                case "B":
                    Console.Clear();
                    ts.LAKEKABALINan();
                    break;
                case "c":
                case "C":
                    Console.Clear();
                    ts.CHOCOLATEHILLS();
                    break;
                case "d":
                case "D":
                    Console.Clear();
                    ts.UNDERWATERCEMETERY();
                    break;
                case "E":
                case "e":
                    Console.Clear();
                    ts.CANIGAOISLAND();
                    break;
                default:
                    Console.Clear();
                    Console.WriteLine("Invalid input");
                    goto Visayas;

            }
        }
        public void SIARGAOisland()
        {

            Program p = new Program();
            TouristSpot ts = new TouristSpot();
            string z,b;
            int person, total, days,d,m,yy;
            int hotelprice;
            ts.Art(1);
            Console.WriteLine("\nSIARGAO ISLAND THE SURFING CAPITAL OF THE PHILIPPINES\nHOTEL NAME:BUDDAH'S SURF HOTEL\nHOTEL PRICE:P4000/day\nPress[Y]to continue Press[N] to browse another spot");
            ts.Art(1);
            z = Console.ReadLine();
            if (z == "y" || z == "Y")
            {
            d:
                Console.WriteLine("Enter Day (DD):");
                d = int.Parse(Console.ReadLine());
                if (d > 0 && d < 32)
                {
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto d;
                }
            m:
                Console.WriteLine("Enter Month (MM):");
                m = int.Parse(Console.ReadLine());
                if (m > 0 && m <= 12)
                {
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto m;
                }
            yy:
                Console.WriteLine("Enter year(YYYY):");
                yy = int.Parse(Console.ReadLine());
                if (yy == 2018)
                {

                }
                else if (yy != 2018)
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto yy;
                }
               
                hotelprice = 4000;
                Console.Write("\nHow many Person:");
                person = int.Parse(Console.ReadLine());
                Console.Write("\nHow many days:");
                days = int.Parse(Console.ReadLine());
                total = ((hotelprice * person) * days);
                Console.Clear();
                Q(1);
                Console.WriteLine("|                         My Travel List                        |");
                Q(1);
                Console.WriteLine("TouristSpot        \tSiargao Island Surfing Capital of the Philippines");
                Console.WriteLine("Location           \tSiargao Philippines");
                Console.WriteLine("Hotel              \tBuddah's Surf Hotel");
                Console.WriteLine("Total person       \t" + person);
                Console.WriteLine("Total Days         \t" + days);
                Console.WriteLine("\nHotel Price      \t" + hotelprice);
                Console.WriteLine("\nSummarize expense\t" + total);
                Console.WriteLine("Date               \t" + d + "/" + m + "/" + yy);
                Q(1);
                Q(2);
                Console.WriteLine("What to do next? Press [Y] to goto Menu and [N] if you want to Logout");
                b = Console.ReadLine();
                if (b == "y" || b == "Y")
                {
                    Console.Clear();
                    p.Browse();
                }
                else if (b != "y" || b != "Y")
                {
                    Console.Clear();
                    Mindanao();
                }
                else if (b == "n" || b == "N")
                {
                    Console.Clear();
                    p.Logout();
                }

            }
            else
            {
                Console.Clear();
                Mindanao();
            }
        }
        public void ENCHANTEDriver()
        {

            Program p = new Program();
            TouristSpot ts = new TouristSpot();
            string z,b;
            int person, total, days,d,m,yy;
            int hotelprice;
            ts.Art(1);
            Console.WriteLine("\nENCHANTED RIVER TANDAG CITY\nHOTEL NAME:OCEAN DRIVE INN\nHOTEL PRICE:P2500/day\nPress[Y]to continue Press[N] to browse another spot");
            ts.Art(1);
            z = Console.ReadLine();
            if (z == "y" || z == "Y")
            {
            d:
                Console.WriteLine("Enter Day (DD):");
                d = int.Parse(Console.ReadLine());
                if (d > 0 && d < 32)
                {
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto d;
                }
            m:
                Console.WriteLine("Enter Month (MM):");
                m = int.Parse(Console.ReadLine());
                if (m > 0 && m <= 12)
                {
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto m;
                }
            yy:
                Console.WriteLine("Enter year(YYYY):");
                yy = int.Parse(Console.ReadLine());
                if (yy == 2018)
                {

                }
                else if (yy != 2018)
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto yy;
                }
               
                hotelprice = 2500;
                Console.Write("\nHow many Person:");
                person = int.Parse(Console.ReadLine());
                Console.Write("\nHow many days:");
                days = int.Parse(Console.ReadLine());
                total = ((hotelprice * person) * days);
                Console.Clear();
                Q(1);
                Console.WriteLine("|                         My Travel List                        |");
                Q(1);
                Console.WriteLine("TouristSpot        \tEnchanted River");
                Console.WriteLine("Location           \tTandag City Philippines");
                Console.WriteLine("Hotel              \tOcean Drive Inn");
                Console.WriteLine("Total person       \t" + person);
                Console.WriteLine("Total Days         \t" + days);
                Console.WriteLine("\nHotel Price      \t" + hotelprice);
                Console.WriteLine("\nSummarize expense\t" + total);
                Console.WriteLine("Date               \t" + d + "/" + m + "/" + yy);
                Q(1);
                Q(2);
                Console.WriteLine("What to do next? Press [Y] to goto Menu and [N] if you want to Logout");
                b = Console.ReadLine();
                if (b == "y" || b == "Y")
                {
                    Console.Clear();
                    p.Browse();
                }
                else if (b != "y" || b != "Y")
                {
                    Console.Clear();
                    Mindanao();
                }
                else if (b == "n" || b == "N")
                {
                    Console.Clear();
                    p.Logout();
                }

            }
            else
            {
                Console.Clear();
                Mindanao();
            }
        }
        public void APO()
        {

            Program p = new Program();
            TouristSpot ts = new TouristSpot();
            string z,b;
            int person, total, days,d,m,yy;
            int hotelprice;
            ts.Art(1);
            Console.WriteLine("\nMT.APO THE TALLEST MOUNTAIN IN THE PHILIPPINES\nHOTEL NAME:GRAND LEGAL HOTEL\nHOTEL PRICE:P3500/day\nPress[Y]to continue Press[N] to browse another spot");
            ts.Art(1);
            z = Console.ReadLine();
            if (z == "y" || z == "Y")
            {
            d:
                Console.WriteLine("Enter Day (DD):");
                d = int.Parse(Console.ReadLine());
                if (d > 0 && d < 32)
                {
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto d;
                }
            m:
                Console.WriteLine("Enter Month (MM):");
                m = int.Parse(Console.ReadLine());
                if (m > 0 && m <= 12)
                {
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto m;
                }
            yy:
                Console.WriteLine("Enter year(YYYY):");
                yy = int.Parse(Console.ReadLine());
                if (yy == 2018)
                {

                }
                else if (yy != 2018)
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto yy;
                }
               
                hotelprice = 2000;
                Console.Write("\nHow many Person:");
                person = int.Parse(Console.ReadLine());
                Console.Write("\nHow many days:");
                days = int.Parse(Console.ReadLine());
                total = ((hotelprice * person) * days);
                Console.Clear();
                Q(1);
                Console.WriteLine("|                         My Travel List                        |");
                Q(1);
                Console.WriteLine("TouristSpot        \tMt.Apo the Tallest Mountain in the Philippines");
                Console.WriteLine("Location           \tDavao Philippines");
                Console.WriteLine("Hotel              \tGrand Legal Hotel");
                Console.WriteLine("Total person       \t" + person);
                Console.WriteLine("Total Days         \t" + days);
                Console.WriteLine("\nHotel Price      \t" + hotelprice);
                Console.WriteLine("\nSummarize expense\t" + total);
                Console.WriteLine("Date               \t" + d + "/" + m + "/" + yy);
                Q(1);
                Q(2);
                Console.WriteLine("What to do next? Press [Y] to goto Menu and [N] if you want to Logout");
                b = Console.ReadLine();
                if (b == "y" || b == "Y")
                {
                    Console.Clear();
                    p.Browse();
                }
                else if (b != "y" || b != "Y")
                {
                    Console.Clear();
                    Mindanao();
                }
                else if (b == "n" || b == "N")
                {
                    Console.Clear();
                    p.Logout();
                }

            }
            else
            {
                Console.Clear();
                Mindanao();
            }
        }
        public void Cagbantoybeach()
        {

            Program p = new Program();
            TouristSpot ts = new TouristSpot();
            string z,b;
            int person, total, days,d,m,yy;
            int hotelprice;
            ts.Art(1);
            Console.WriteLine("\nCAGBANTOY BEACH SURIGAO DEL NORTE\nHOTEL NAME:THE GRAND SUITE\nHOTEL PRICE:P2500/day\nPress[Y]to continue Press[N] to browse another spot");
            ts.Art(1);
            z = Console.ReadLine();
            if (z == "y" || z == "Y")
            {
            d:
                Console.WriteLine("Enter Day (DD):");
                d = int.Parse(Console.ReadLine());
                if (d > 0 && d < 32)
                {
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto d;
                }
            m:
                Console.WriteLine("Enter Month (MM):");
                m = int.Parse(Console.ReadLine());
                if (m > 0 && m <= 12)
                {
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto m;
                }
            yy:
                Console.WriteLine("Enter year(YYYY):");
                yy = int.Parse(Console.ReadLine());
                if (yy == 2018)
                {

                }
                else if (yy != 2018)
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto yy;
                }
               
                hotelprice = 2500;
                Console.Write("\nHow many Person:");
                person = int.Parse(Console.ReadLine());
                Console.Write("\nHow many days:");
                days = int.Parse(Console.ReadLine());
                total = ((hotelprice * person) * days);
                Console.Clear();
                Q(1);
                Console.WriteLine("|                         My Travel List                        |");
                Q(1);
                Console.WriteLine("TouristSpot        \tCagbantoy Beach");
                Console.WriteLine("Location           \tPlacer Surigao Del Norte Philippines");
                Console.WriteLine("Hotel              \tThe Grand Suite Hotel");
                Console.WriteLine("Total person       \t" + person);
                Console.WriteLine("Total Days         \t" + days);
                Console.WriteLine("\nHotel Price      \t" + hotelprice);
                Console.WriteLine("\nSummarize expense\t" + total);
                Console.WriteLine("Date               \t" + d + "/" + m + "/" + yy);
                Q(1);
                Q(2);
                Console.WriteLine("What to do next? Press [Y] to goto Menu and [N] if you want to Logout");
                b = Console.ReadLine();
                if (b == "y" || b == "Y")
                {
                    Console.Clear();
                    p.Browse();
                }
                else if (b != "y" || b != "Y")
                {
                    Console.Clear();
                    Mindanao();
                }
                else if (b == "n" || b == "N")
                {
                    Console.Clear();
                    p.Logout();
                }

            }
            else
            {
                Console.Clear();
                Mindanao();
            }
        }
        public void MABUABEACH()
        {

            Program p = new Program();
            TouristSpot ts = new TouristSpot();
            string z,b;
            int person, total, days,d,m,yy;
            int hotelprice;
            ts.Art(1);
            Console.WriteLine("\nALMONT BEACH RESORT MABUA SURIGAO DEL NORTE\nHOTEL NAME:PARKWAY HOTEL\nHOTEL PRICE:P3500/day\nPress[Y]to continue Press[N] to browse another spot");
            ts.Art(1);
            z = Console.ReadLine();
            if (z == "y" || z == "Y")
            {
            d:
                Console.WriteLine("Enter Day (DD):");
                d = int.Parse(Console.ReadLine());
                if (d > 0 && d < 32)
                {
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto d;
                }
            m:
                Console.WriteLine("Enter Month (MM):");
                m = int.Parse(Console.ReadLine());
                if (m > 0 && m <= 12)
                {
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto m;
                }
            yy:
                Console.WriteLine("Enter year(YYYY):");
                yy = int.Parse(Console.ReadLine());
                if (yy == 2018)
                {

                }
                else if (yy != 2018)
                {
                    Console.Clear();
                    Console.WriteLine("invalid input");
                    goto yy;
                }
               
                hotelprice = 3500;
                Console.Write("\nHow many Person:");
                person = int.Parse(Console.ReadLine());
                Console.Write("\nHow many days:");
                days = int.Parse(Console.ReadLine());
                total = ((hotelprice * person) * days);
                Console.Clear();
                Q(1);
                Console.WriteLine("|                         My Travel List                        |");
                Q(1);
                Console.WriteLine("TouristSpot        \tAlmont Beach Resort");
                Console.WriteLine("Location           \tMabua Surigao Del Norte Philippines");
                Console.WriteLine("Hotel              \tView Park Hotel");
                Console.WriteLine("Total person       \t" + person);
                Console.WriteLine("Total Days         \t" + days);
                Console.WriteLine("\nHotel Price      \t" + hotelprice);
                Console.WriteLine("\nSummarize expense\t" + total);
                Console.WriteLine("Date               \t" + d + "/" + m + "/" + yy);
                Q(1);
                Q(2);
                Console.WriteLine("What to do next? Press [Y] to goto Menu and [N] if you want to Logout");
                b = Console.ReadLine();
                if (b == "y" || b == "Y")
                {
                    Console.Clear();
                    p.Browse();
                }
                else if (b != "y" || b != "Y")
                {
                    Console.Clear();
                    Mindanao();
                }
                else if (b == "n" || b == "N")
                {
                    Console.Clear();
                    p.Logout();
                }

            }
            else
            {
                Console.Clear();
                Mindanao();
            }
        }
        public void Mindanao()
        {
            Program p = new Program();
        Mindanao:
            String M;
            Art(1);
            Console.WriteLine("\nWelcome to Visayas's TOP 5 Tourist Spots\nHappy Browsing");
            Art(1);
            Console.WriteLine("\nA.Siargao Island\nB.Enchanted River\nC.Mt.Apo\nD.Cagbantoy Beach\nE.Almont Beach Resort");
            Art(1);
            Console.Write("\nkindly choose:\t");
            M = Console.ReadLine();
            switch (M)
            {
                case "A":
                case "a":
                    Console.Clear();
                    SIARGAOisland();
                    break;
                case "b":
                case "B":
                    Console.Clear();
                    ENCHANTEDriver();
                    break;
                case "c":
                case "C":
                    Console.Clear();
                    APO();
                    break;
                case "d":
                case "D":
                    Cagbantoybeach();
                    break;
                case "e":
                case "E":
                    MABUABEACH();
                    break;
                default:
                    Console.Clear();
                    Console.WriteLine("Invalid input");
                    goto Mindanao;
            }
        }
        public void Art(byte d)
        {
            for (int c = 1; c <= d; c++)
            {
                Console.WriteLine("\nxoxoxoxoxoxoxoxoxoxox xoxoxoxoxoxoxoxoxoxox xoxoxoxoxoxoxoxoxoxox");
            }
        }
        public void Q(byte e)
        {
            for (int g = 1; g <= e; g++)
            {
                Console.WriteLine("_________________________________________________________________");
            }
        }
        public void Thankyou(byte s)
        {
            for (int m = 1; m <= s; m++)
            {
                Console.WriteLine("HELLO WORLD !!! THANKYOU FOR BROWSING :) GODBLESS");
            }
        }
    }
}

