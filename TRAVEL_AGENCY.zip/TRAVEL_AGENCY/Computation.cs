﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TRAVEL_AGENCY
{
    class Computation
    {
        public void Computation1()
        {
            double Person, Total, Days;
            string Username;
            Console.WriteLine("Enter your Username:");
            Username = Console.ReadLine();
            Console.Write("Please enter How many Person:");
            Person = double.Parse(Console.ReadLine());
            Console.Write("Please enter How many Days:");
            Days = double.Parse(Console.ReadLine());
            Total = ((Person * Days) * 2000);
            Console.WriteLine("your Total Expenses\t" + Total);
            Console.WriteLine("Thankyou for Browsing \t" + Username);

        }
        public void Computation2()
        {
            double Person, Total, Days;
            string Username;
            Console.WriteLine("Enter your Username:");
            Username = Console.ReadLine();
            Console.Write("Please enter How many Person:");
            Person = double.Parse(Console.ReadLine());
            Console.Write("Please enter How many Days:");
            Days = double.Parse(Console.ReadLine());
            Total = ((Person * Days) * 3000);
            Console.WriteLine("your Total Expenses\t" + Total);
            Console.WriteLine("Thankyou for Browsing \t" + Username);


        }
        public void Computation3()
        {
            double Person, Total, Days;
            string Username;
            Console.WriteLine("Enter your Username:");
            Username = Console.ReadLine();
            Console.Write("Please enter How many Person:");
            Person = double.Parse(Console.ReadLine());
            Console.Write("Please enter How many Days:");
            Days = double.Parse(Console.ReadLine());
            Total = ((Person * Days) * 2500);
            Console.WriteLine("your Total Expenses\t" + Total);
            Console.WriteLine("Thankyou for Browsing \t" + Username);
        }
        public void Computation4()
        {
            double Person, Total, Days;
            string Username;
            Console.WriteLine("Enter your Username:");
            Username = Console.ReadLine();
            Console.Write("Please enter How many Person:");
            Person = double.Parse(Console.ReadLine());
            Console.Write("Please enter How many Days:");
            Days = double.Parse(Console.ReadLine());
            Total = ((Person * Days) * 4000);
            Console.WriteLine("your Total Expenses\t" + Total);
            Console.WriteLine("Thankyou for Browsing \t" + Username);
        }
        public void Computation5()
        {
            double Person, Total, Days;
            string Username;
            Console.WriteLine("Enter your Username:");
            Username = Console.ReadLine();
            Console.Write("Please enter How many Person:");
            Person = double.Parse(Console.ReadLine());
            Console.Write("Please enter How many Days:");
            Days = double.Parse(Console.ReadLine());
            Total = ((Person * Days) * 7000);
            Console.WriteLine("your Total Expenses\t" + Total);
            Console.WriteLine("Thankyou for Browsing \t" + Username);
        }
        public void Computation6()
        {
            double Person, Total, Days;
            string Username;
            Console.WriteLine("Enter your Username:");
            Username = Console.ReadLine();
            Console.Write("Please enter How many Person:");
            Person = double.Parse(Console.ReadLine());
            Console.Write("Please enter How many Days:");
            Days = double.Parse(Console.ReadLine());
            Total = ((Person * Days) * 2000);
            Console.WriteLine("your Total Expenses\t" + Total);
            Console.WriteLine("Thankyou for Browsing \t" + Username);
        }
        public void Computation7()
        {
            double Person, Total, Days;
            string Username;
            Console.WriteLine("Enter your Username:");
            Username = Console.ReadLine();
            Console.Write("Please enter How many Person:");
            Person = double.Parse(Console.ReadLine());
            Console.Write("Please enter How many Days:");
            Days = double.Parse(Console.ReadLine());
            Total = ((Person * Days) * 3000);
            Console.WriteLine("your Total Expenses\t" + Total);
            Console.WriteLine("Thankyou for Browsing \t" + Username);
        }
        public void Computation8()
        {
            double Person, Total, Days;
            string Username;
            Console.WriteLine("Enter your Username:");
            Username = Console.ReadLine();
            Console.Write("Please enter How many Person:");
            Person = double.Parse(Console.ReadLine());
            Console.Write("Please enter How many Days:");
            Days = double.Parse(Console.ReadLine());
            Total = ((Person * Days) * 2500);
            Console.WriteLine("your Total Expenses\t" + Total);
            Console.WriteLine("Thankyou for Browsing \t" + Username);
        }
        public void Computation9()
        {
            double Person, Total, Days;
            string Username;
            Console.WriteLine("Enter your Username:");
            Username = Console.ReadLine();
            Console.Write("Please enter How many Person:");
            Person = double.Parse(Console.ReadLine());
            Console.Write("Please enter How many Days:");
            Days = double.Parse(Console.ReadLine());
            Total = ((Person * Days) * 2000);
            Console.WriteLine("your Total Expenses\t" + Total);
            Console.WriteLine("Thankyou for Browsing \t" + Username);
        }
        public void Computation10()
        {
            double Person, Total, Days;
            string Username;
            Console.WriteLine("Enter your Username:");
            Username = Console.ReadLine();
            Console.Write("Please enter How many Person:");
            Person = double.Parse(Console.ReadLine());
            Console.Write("Please enter How many Days:");
            Days = double.Parse(Console.ReadLine());
            Total = ((Person * Days) * 1500);
            Console.WriteLine("your Total Expenses\t" + Total);
            Console.WriteLine("Thankyou for Browsing \t" + Username);
        }
        public void Computation11()
        {
            double Person, Total, Days;
            string Username;
            Console.WriteLine("Enter your Username:");
            Username = Console.ReadLine();
            Console.Write("Please enter How many Person:");
            Person = double.Parse(Console.ReadLine());
            Console.Write("Please enter How many Days:");
            Days = double.Parse(Console.ReadLine());
            Total = ((Person * Days) * 4000);
            Console.WriteLine("your Total Expenses\t" + Total);
            Console.WriteLine("Thankyou for Browsing \t" + Username);
        }
        public void Computation12()
        {
            double Person, Total, Days;
            string Username;
            Console.WriteLine("Enter your Username:");
            Username = Console.ReadLine();
            Console.Write("Please enter How many Person:");
            Person = double.Parse(Console.ReadLine());
            Console.Write("Please enter How many Days:");
            Days = double.Parse(Console.ReadLine());
            Total = ((Person * Days) * 2500);
            Console.WriteLine("your Total Expenses\t" + Total);
            Console.WriteLine("Thankyou for Browsing \t" + Username);
        }
        public void Computation13()
        {
            double Person, Total, Days;
            string Username;
            Console.WriteLine("Enter your Username:");
            Username = Console.ReadLine();
            Console.Write("Please enter How many Person:");
            Person = double.Parse(Console.ReadLine());
            Console.Write("Please enter How many Days:");
            Days = double.Parse(Console.ReadLine());
            Total = ((Person * Days) * 3500);
            Console.WriteLine("your Total Expenses\t" + Total);
            Console.WriteLine("Thankyou for Browsing \t" + Username);
        }
        public void Computation14()
        {
            double Person, Total, Days;
            string Username;
            Console.WriteLine("Enter your Username:");
            Username = Console.ReadLine();
            Console.Write("Please enter How many Person:");
            Person = double.Parse(Console.ReadLine());
            Console.Write("Please enter How many Days:");
            Days = double.Parse(Console.ReadLine());
            Total = ((Person * Days) * 2500);
            Console.WriteLine("your Total Expenses\t" + Total);
            Console.WriteLine("Thankyou for Browsing \t" + Username);
        }
        public void Computation15()
        {
            double Person, Total, Days;
            string Username;
            Console.WriteLine("Enter your Username:");
            Username = Console.ReadLine();
            Console.Write("Please enter How many Person:");
            Person = double.Parse(Console.ReadLine());
            Console.Write("Please enter How many Days:");
            Days = double.Parse(Console.ReadLine());
            Total = ((Person * Days) * 3500);
            Console.WriteLine("your Total Expenses\t" + Total);
            Console.WriteLine("Thankyou for Browsing \t" + Username);
        }

    }
}