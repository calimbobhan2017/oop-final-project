﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TRAVEL_AGENCY
{
    class Update
    {
        public String Spot, Hotel, Id;
        int Total,Person,Days;

        public Update(String id,String spot, String hotel,int person,int days,int total)
        {
            this.Person=person;
            this.Days = days;
            //this.Value = value;
            this.Hotel = hotel;
            this.Spot = spot;
            this.Id = id;
            this.Total = total;
        }
        public String toString()
        {
            return
                   //"\n\tDate                =\t'" + Value   +'\'' +
                   "\n\tHotel               =\t'" + Hotel  +'\'' +
                   "\n\tSpot                =\t'" + Spot   +'\'' +
                   "\n\tNo. of Persons      =\t'" + Person +'\'' +
                   "\n\tNo.of Days          =\t'" + Days   +'\'' +
                   "\n\tSummarize Expense   =\t'" + Total  +'\'' +
                   ' ';
        }
        public Update(String id, String hotel, String spot)
        {
            Hotel = hotel;
            Spot = spot;
            Id = id;
        }

    }
}

