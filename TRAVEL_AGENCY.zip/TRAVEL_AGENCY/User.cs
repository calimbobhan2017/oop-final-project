﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TRAVEL_AGENCY
{
    class User
    {
        protected internal String FirstName, LastName, MiddleName, Username, Password, Id;

        public User(String id, String firstname, String lastname, String middlename, String username, String password)
        {
            this.FirstName = firstname;
            this.LastName = lastname;
            this.MiddleName = middlename;
            this.Username = username;
            this.Password = password;
            this.Id = id;
        }
        protected internal String toString()
        {
            return
                  "]  \n\tId           =\t'" + Id + '\'' +
                    " \n\tFirstName    =\t'" + FirstName + '\'' +
                    " \n\tLastName     =\t'" + LastName + '\'' +
                    " \n\tMiddleName   =\t'" + MiddleName + '\'' +
                    " \n\tUsername     =\t'" + Username + '\'' +
                    " \n\tPassword     =\t'" + Password + '\'' +
                    ']';
        }
        protected internal User(String id, String firstName, String lastName)
        {
            FirstName = firstName;
            LastName = lastName;
            Id = id;
        }
    }
}
